<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=yes">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $seoTitle ?? 'RS Emblem - Advanced Materials & Machinery' }}</title>
<meta name="description" content="{{ $seoDescription ?? 'Industrial materials, polymers, TPU heat transfer, printing chemicals, and machinery solutions from Bangladesh.' }}">
<meta name="keywords" content="{{ $seoKeywords ?? 'industrial materials, machinery, printing materials, polymers, Bangladesh' }}">
<meta name="author" content="RS Emblem">
<meta name="robots" content="index, follow">
<link rel="canonical" href="{{ url()->current() }}">
<meta property="og:type" content="website">
<meta property="og:title" content="{{ $seoTitle ?? 'RS Emblem' }}">
<meta property="og:description" content="{{ $seoDescription ?? 'Premium industrial solutions' }}">
<meta property="og:url" content="{{ url()->current() }}">
<meta property="og:image" content="{{ asset('assets/og-image.jpg') }}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{ $seoTitle ?? 'RS Emblem' }}">
<meta name="twitter:description" content="{{ $seoDescription ?? 'Premium industrial solutions' }}">
<meta name="twitter:image" content="{{ asset('assets/og-image.jpg') }}">
<link rel="icon" type="image/x-icon" href="{{ asset('favicon.ico') }}">
<link rel="apple-touch-icon" href="{{ asset('assets/apple-touch-icon.png') }}">
<link rel="preload" href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" as="style">
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link rel="stylesheet" href="{{ asset('assets/style.css') }}">
<script src="https://cdn.tailwindcss.com" defer></script>
</head>
<body>
<nav>
<a href="{{ route('home') }}" class="nav-logo">
<div class="logo-mark">RS</div>
<div class="logo-text">RS Emblem<br><span>New Materials Technology</span></div>
</a>
<ul class="nav-links" id="navLinks">
<li><a href="{{ route('home') }}">Home</a></li>
<li><a href="{{ route('about') }}">About</a></li>
<li class="nav-dropdown-wrapper">
<button id="productBtn" class="nav-dropdown-btn">Products<i class="fas fa-chevron-down"></i></button>
<ul id="productDropdown" class="nav-dropdown-menu hidden">
<li><a href="{{ route('machinery') }}">Machinery</a></li>
<li><a href="{{ route('materials') }}">Raw Materials</a></li>
</ul>
</li>
<li><a href="{{ route('solutions') }}">Solutions</a></li>
<li><a href="{{ route('blog') }}">Blog</a></li>
<li><a href="{{ route('contact') }}" class="nav-cta">Contact Now</a></li>
</ul>
<div class="hamburger" id="hamburger"><span></span><span></span><span></span></div>
</nav>
@yield('content')
<footer id="contact">
<div class="container">
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px,1fr)); gap: 50px; margin-bottom: 48px; position: relative;">
<div>
<div class="logo-mark" style="margin-bottom: 16px;">RS</div>
<h4 style="color: white; font-weight: 700; margin-bottom: 8px;">RS Emblem</h4>
<p style="color: #94A3B8; font-size: 13px; line-height: 1.6;">Advanced printing materials &amp; industrial solutions since 2020.</p>
</div>
<div>
<h4 style="color: var(--primary-red); margin-bottom: 20px; font-size: 16px;">Navigation</h4>
<ul style="list-style: none; line-height: 2.2; padding: 0; margin: 0;">
<li><a href="{{ route('home') }}" style="color: #CBD5E1; text-decoration: none;">Home</a></li>
<li><a href="{{ route('about') }}" style="color: #CBD5E1; text-decoration: none;">About</a></li>
<li><a href="{{ route('machinery') }}" style="color: #CBD5E1; text-decoration: none;">Products</a></li>
<li><a href="{{ route('solutions') }}" style="color: #CBD5E1; text-decoration: none;">Solutions</a></li>
<li><a href="{{ route('blog') }}" style="color: #CBD5E1; text-decoration: none;">Blog</a></li>
</ul>
</div>
<div>
<h4 style="color: var(--primary-red); margin-bottom: 20px; font-size: 16px;">Contact Info</h4>
<p style="color: #CBD5E1; font-size: 13px; margin: 0 0 12px 0;"><i class="fas fa-map-marker-alt" style="margin-right: 10px; color: var(--primary-red);"></i> Ashulia, Savar, Dhaka-1341</p>
<p style="color: #CBD5E1; font-size: 13px; margin: 0 0 12px 0;"><i class="fas fa-phone-alt" style="margin-right: 10px; color: var(--primary-red);"></i> +8801931669605</p>
<p style="color: #CBD5E1; font-size: 13px; margin: 0;"><i class="fas fa-envelope" style="margin-right: 10px; color: var(--primary-red);"></i> rsemblem2022@gmail.com</p>
</div>
<div>
<h4 style="color: var(--primary-red); margin-bottom: 20px; font-size: 16px;">Quick Inquiry</h4>
<p style="color: #CBD5E1; font-size: 13px; margin-bottom: 16px;">Need help? Contact us today.</p>
<a href="mailto:rsemblem2022@gmail.com" class="btn-circle btn-primary" style="display: inline-block;">Email Us</a>
</div>
</div>
<div style="border-top: 1px solid #1E2F44; padding-top: 24px; text-align: center;">
<p style="margin: 0; font-size: 13px;">© 2025 RS Emblem. All rights reserved.</p>
</div>
<a href="https://wa.me/8801931669605" target="_blank" rel="noopener noreferrer" style="position: fixed; bottom: 30px; right: 30px; display: inline-flex; align-items: center; justify-content: center; width: 50px; height: 50px; background-color: #25D366; color: white; border-radius: 50%; z-index: 999;"><i class="fab fa-whatsapp" style="font-size: 24px;"></i></a>
</div>
</footer>
<script src="{{ asset('assets/script.js') }}" defer></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXX"></script>
<script>window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-XXXXXXXX');</script>
<script type="application/ld+json">{"@context":"https://schema.org","@type":"Organization","name":"RS Emblem","url":"{{ url('/') }}","description":"Advanced printing materials and industrial machinery solutions","address":{"@type":"PostalAddress","streetAddress":"Ashulia","addressLocality":"Savar","addressRegion":"Dhaka","postalCode":"1341","addressCountry":"BD"},"contact":{"@type":"ContactPoint","contactType":"Sales","telephone":"+8801931669605","email":"rsemblem2022@gmail.com"}}</script>
<script type="application/ld+json">{"@context":"https://schema.org","@type":"LocalBusiness","name":"RS Emblem","description":"Industrial materials &amp; machinery solutions","telephone":"+8801931669605","email":"rsemblem2022@gmail.com","url":"{{ url('/') }}","address":{"@type":"PostalAddress","streetAddress":"Ashulia, Savar","addressLocality":"Dhaka","addressRegion":"Dhaka","postalCode":"1341","addressCountry":"BD"},"geo":{"@type":"GeoCoordinates","latitude":"23.9000","longitude":"90.2000"}}</script>
</body>
</html>

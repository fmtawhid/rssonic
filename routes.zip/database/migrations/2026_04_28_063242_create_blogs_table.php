<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up(): void
{
    Schema::create('blogs', function (Blueprint $table) {
        $table->id();

        $table->string('title');
        $table->string('slug')->unique();

        $table->text('excerpt')->nullable();
        $table->longText('content');

        $table->string('image')->nullable();

        $table->unsignedBigInteger('category_id')->nullable();

        $table->string('meta_title')->nullable();
        $table->text('meta_description')->nullable();

        $table->boolean('is_published')->default(false);
        $table->timestamp('published_at')->nullable();

        $table->integer('views_count')->default(0);

        $table->timestamps();
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('blogs');
    }
};
